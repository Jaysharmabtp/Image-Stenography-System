# Image Steganography System

A modern Python application for hiding and extracting secret text messages in images using LSB (Least Significant Bit) steganography technique.

## Features

- **Modern GUI**: Clean and intuitive user interface built with Tkinter
- **Hide Messages**: Encode secret text messages into images
- **Extract Messages**: Decode hidden messages from steganographic images
- **Multiple Formats**: Support for PNG, JPEG, BMP, and TIFF image formats
- **Error Handling**: Comprehensive error handling and user feedback
- **Message Validation**: Automatic validation of message length and image capacity
- **Copy to Clipboard**: Easy copying of decoded messages

## How It Works

The application uses LSB (Least Significant Bit) steganography to hide text messages in images:

1. **Encoding**: The text message is converted to binary and embedded into the least significant bits of the image pixels
2. **Decoding**: The hidden binary data is extracted from the LSB of pixels and converted back to text
3. **Delimiter**: A special binary sequence marks the end of the hidden message

## Installation

1. **Clone or download** this repository
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Running the Application

```bash
python ImageS_improved.py
```

### Encoding a Message

1. Click **"📝 Encode Message"**
2. Select an image file (PNG, JPEG, BMP, TIFF)
3. Enter your secret message in the text area
4. Click **"🔐 Encode Message"**
5. Choose where to save the encoded image

### Decoding a Message

1. Click **"🔍 Decode Message"**
2. Select an image with a hidden message
3. The hidden message will be automatically extracted and displayed
4. Use **"📋 Copy Message"** to copy the text to clipboard

## Requirements

- Python 3.6+
- Pillow (PIL) 9.0.0+
- Tkinter (usually included with Python)

## Technical Details

### Steganography Algorithm

- **Method**: LSB (Least Significant Bit) substitution
- **Channels**: RGB channels of image pixels
- **Capacity**: Approximately (width × height × 3) ÷ 8 characters per image
- **Delimiter**: Binary sequence `1111111111111110` marks message end

### Security Considerations

- This is a basic steganography implementation for educational purposes
- The hidden messages are not encrypted, only hidden
- For sensitive data, consider adding encryption before hiding the message

## File Structure

```
Image-Stenography-System/
├── ImageS_improved.py      # Main application (improved version)
├── ImageS.py              # Original application
├── requirements.txt       # Python dependencies
├── README_updated.md      # This documentation
└── README.md             # Original README
```

## Improvements Made

### Code Quality
- **Object-oriented design** with proper class structure
- **Error handling** for all major operations
- **Input validation** for messages and images
- **Clean code** with proper documentation and comments

### User Interface
- **Modern design** with improved colors and layout
- **Better navigation** with clear back buttons
- **Visual feedback** with icons and status messages
- **Responsive layout** with proper window centering

### Functionality
- **Multiple image format support**
- **Message length validation**
- **Copy to clipboard feature**
- **Better file dialogs** with proper filters
- **Improved image display** with proper scaling

### Performance
- **Efficient pixel manipulation**
- **Memory optimization** for large images
- **Better error recovery**

## Troubleshooting

### Common Issues

1. **"No hidden message found"**
   - The selected image doesn't contain a hidden message
   - The image may be corrupted or modified after encoding

2. **"Message too long"**
   - The text message exceeds the image capacity
   - Try using a larger image or shorter message

3. **"Invalid image file"**
   - The selected file is not a valid image
   - Try using PNG, JPEG, BMP, or TIFF formats

### Tips

- **Use PNG format** for best results (lossless compression)
- **Avoid JPEG** for encoded images as compression may corrupt hidden data
- **Keep original images** as backup before encoding
- **Test with small messages** first to ensure everything works

## License

This project is open source and available under the MIT License.

## Contributing

Feel free to fork this project and submit pull requests for improvements!

## Author

Original concept by Jay Sharma
Improved and modernized version with enhanced features and better code structure.
