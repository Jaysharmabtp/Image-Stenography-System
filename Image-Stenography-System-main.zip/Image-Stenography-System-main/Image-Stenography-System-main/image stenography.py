import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import ImageTk, Image
from io import BytesIO
import os
import sys


class ImageSteganography:
    """A class for hiding and extracting text messages in images using LSB steganography."""
    
    def __init__(self):
        self.output_image_size = 0
        self.original_image_path = None
        self.encoded_image_path = None
        self.root = None
        
        # ASCII art for decoration
        self.welcome_art = r'''¯\_(ツ)_/¯'''
        self.encode_art = r'''\'\ (°Ω°) /\''''
        self.decode_art = '''٩(^‿^)۶'''

    def create_main_window(self):
        """Create and configure the main application window."""
        self.root = tk.Tk()
        self.root.title('Image Steganography Tool')
        self.root.geometry('600x700')
        self.root.resizable(width=False, height=False)
        self.root.configure(bg='#f0f0f0')
        
        # Center the window
        self.center_window()
        
        self.show_main_menu()
        return self.root

    def center_window(self):
        """Center the window on the screen."""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

    def clear_window(self):
        """Clear all widgets from the window."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_main_menu(self):
        """Display the main menu interface."""
        self.clear_window()
        
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            main_frame, 
            text='Image Steganography Tool',
            font=('Arial', 28, 'bold'),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        title_label.pack(pady=(20, 10))
        
        # Subtitle
        subtitle_label = tk.Label(
            main_frame,
            text='Hide and extract secret messages in images',
            font=('Arial', 12),
            bg='#f0f0f0',
            fg='#7f8c8d'
        )
        subtitle_label.pack(pady=(0, 30))
        
        # ASCII Art
        art_label = tk.Label(
            main_frame,
            text=self.welcome_art,
            font=('Courier', 40),
            bg='#f0f0f0',
            fg='#3498db'
        )
        art_label.pack(pady=20)
        
        # Buttons frame
        button_frame = tk.Frame(main_frame, bg='#f0f0f0')
        button_frame.pack(pady=30)
        
        # Encode button
        encode_btn = tk.Button(
            button_frame,
            text='📝 Encode Message',
            command=self.show_encode_menu,
            font=('Arial', 14, 'bold'),
            bg='#27ae60',
            fg='white',
            padx=30,
            pady=15,
            relief='flat',
            cursor='hand2'
        )
        encode_btn.pack(pady=10)
        
        # Decode button
        decode_btn = tk.Button(
            button_frame,
            text='🔍 Decode Message',
            command=self.show_decode_menu,
            font=('Arial', 14, 'bold'),
            bg='#e74c3c',
            fg='white',
            padx=30,
            pady=15,
            relief='flat',
            cursor='hand2'
        )
        decode_btn.pack(pady=10)
        
        # Exit button
        exit_btn = tk.Button(
            button_frame,
            text='❌ Exit',
            command=self.root.quit,
            font=('Arial', 12),
            bg='#95a5a6',
            fg='white',
            padx=20,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        exit_btn.pack(pady=(20, 0))

    def show_encode_menu(self):
        """Display the encode menu interface."""
        self.clear_window()
        
        encode_frame = tk.Frame(self.root, bg='#f0f0f0')
        encode_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            encode_frame,
            text='Encode Secret Message',
            font=('Arial', 24, 'bold'),
            bg='#f0f0f0',
            fg='#27ae60'
        )
        title_label.pack(pady=20)
        
        # ASCII Art
        art_label = tk.Label(
            encode_frame,
            text=self.encode_art,
            font=('Courier', 30),
            bg='#f0f0f0',
            fg='#27ae60'
        )
        art_label.pack(pady=20)
        
        # Instructions
        instruction_label = tk.Label(
            encode_frame,
            text='Select an image to hide your secret message in:',
            font=('Arial', 14),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        instruction_label.pack(pady=20)
        
        # Button frame
        button_frame = tk.Frame(encode_frame, bg='#f0f0f0')
        button_frame.pack(pady=20)
        
        # Select image button
        select_btn = tk.Button(
            button_frame,
            text='📁 Select Image',
            command=self.select_image_for_encoding,
            font=('Arial', 12, 'bold'),
            bg='#3498db',
            fg='white',
            padx=20,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        select_btn.pack(pady=10)
        
        # Back button
        back_btn = tk.Button(
            button_frame,
            text='⬅️ Back to Main Menu',
            command=self.show_main_menu,
            font=('Arial', 10),
            bg='#95a5a6',
            fg='white',
            padx=15,
            pady=8,
            relief='flat',
            cursor='hand2'
        )
        back_btn.pack(pady=10)

    def show_decode_menu(self):
        """Display the decode menu interface."""
        self.clear_window()
        
        decode_frame = tk.Frame(self.root, bg='#f0f0f0')
        decode_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            decode_frame,
            text='Decode Hidden Message',
            font=('Arial', 24, 'bold'),
            bg='#f0f0f0',
            fg='#e74c3c'
        )
        title_label.pack(pady=20)
        
        # ASCII Art
        art_label = tk.Label(
            decode_frame,
            text=self.decode_art,
            font=('Courier', 30),
            bg='#f0f0f0',
            fg='#e74c3c'
        )
        art_label.pack(pady=20)
        
        # Instructions
        instruction_label = tk.Label(
            decode_frame,
            text='Select an image with a hidden message:',
            font=('Arial', 14),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        instruction_label.pack(pady=20)
        
        # Button frame
        button_frame = tk.Frame(decode_frame, bg='#f0f0f0')
        button_frame.pack(pady=20)
        
        # Select image button
        select_btn = tk.Button(
            button_frame,
            text='📁 Select Image',
            command=self.select_image_for_decoding,
            font=('Arial', 12, 'bold'),
            bg='#3498db',
            fg='white',
            padx=20,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        select_btn.pack(pady=10)
        
        # Back button
        back_btn = tk.Button(
            button_frame,
            text='⬅️ Back to Main Menu',
            command=self.show_main_menu,
            font=('Arial', 10),
            bg='#95a5a6',
            fg='white',
            padx=15,
            pady=8,
            relief='flat',
            cursor='hand2'
        )
        back_btn.pack(pady=10)

    def select_image_for_encoding(self):
        """Handle image selection for encoding."""
        try:
            file_path = filedialog.askopenfilename(
                title="Select Image for Encoding",
                filetypes=[
                    ('Image files', '*.png *.jpg *.jpeg *.bmp *.tiff'),
                    ('PNG files', '*.png'),
                    ('JPEG files', '*.jpg *.jpeg'),
                    ('All files', '*.*')
                ]
            )
            
            if not file_path:
                return
            
            # Validate image
            try:
                img = Image.open(file_path)
                self.original_image_path = file_path
                self.show_encoding_interface(img)
            except Exception as e:
                messagebox.showerror("Error", f"Invalid image file: {str(e)}")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to select image: {str(e)}")

    def select_image_for_decoding(self):
        """Handle image selection for decoding."""
        try:
            file_path = filedialog.askopenfilename(
                title="Select Image for Decoding",
                filetypes=[
                    ('Image files', '*.png *.jpg *.jpeg *.bmp *.tiff'),
                    ('PNG files', '*.png'),
                    ('JPEG files', '*.jpg *.jpeg'),
                    ('All files', '*.*')
                ]
            )
            
            if not file_path:
                return
            
            # Validate image
            try:
                img = Image.open(file_path)
                self.show_decoding_interface(img, file_path)
            except Exception as e:
                messagebox.showerror("Error", f"Invalid image file: {str(e)}")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to select image: {str(e)}")

    def show_encoding_interface(self, image):
        """Display the encoding interface with selected image."""
        self.clear_window()
        
        encode_frame = tk.Frame(self.root, bg='#f0f0f0')
        encode_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            encode_frame,
            text='Encode Message in Image',
            font=('Arial', 20, 'bold'),
            bg='#f0f0f0',
            fg='#27ae60'
        )
        title_label.pack(pady=10)
        
        # Image display
        try:
            display_image = image.copy()
            display_image.thumbnail((300, 200), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(display_image)
            
            image_label = tk.Label(encode_frame, image=photo, bg='#f0f0f0')
            image_label.image = photo  # Keep a reference
            image_label.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display image: {str(e)}")
            return
        
        # Message input
        message_label = tk.Label(
            encode_frame,
            text='Enter your secret message:',
            font=('Arial', 12, 'bold'),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        message_label.pack(pady=(20, 5))
        
        # Text area with scrollbar
        text_frame = tk.Frame(encode_frame, bg='#f0f0f0')
        text_frame.pack(pady=10)
        
        text_area = tk.Text(
            text_frame,
            width=50,
            height=8,
            font=('Arial', 10),
            wrap=tk.WORD,
            relief='solid',
            borderwidth=1
        )
        scrollbar = tk.Scrollbar(text_frame, orient='vertical', command=text_area.yview)
        text_area.configure(yscrollcommand=scrollbar.set)
        
        text_area.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Button frame
        button_frame = tk.Frame(encode_frame, bg='#f0f0f0')
        button_frame.pack(pady=20)
        
        # Encode button
        encode_btn = tk.Button(
            button_frame,
            text='🔐 Encode Message',
            command=lambda: self.encode_message(text_area, image),
            font=('Arial', 12, 'bold'),
            bg='#27ae60',
            fg='white',
            padx=20,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        encode_btn.pack(side='left', padx=5)
        
        # Back button
        back_btn = tk.Button(
            button_frame,
            text='⬅️ Back',
            command=self.show_encode_menu,
            font=('Arial', 10),
            bg='#95a5a6',
            fg='white',
            padx=15,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        back_btn.pack(side='left', padx=5)

    def show_decoding_interface(self, image, file_path):
        """Display the decoding interface with selected image."""
        self.clear_window()
        
        decode_frame = tk.Frame(self.root, bg='#f0f0f0')
        decode_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            decode_frame,
            text='Decode Hidden Message',
            font=('Arial', 20, 'bold'),
            bg='#f0f0f0',
            fg='#e74c3c'
        )
        title_label.pack(pady=10)
        
        # Image display
        try:
            display_image = image.copy()
            display_image.thumbnail((300, 200), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(display_image)
            
            image_label = tk.Label(decode_frame, image=photo, bg='#f0f0f0')
            image_label.image = photo  # Keep a reference
            image_label.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display image: {str(e)}")
            return
        
        # Decode the message
        try:
            hidden_message = self.decode_message(image)
            
            # Message display
            message_label = tk.Label(
                decode_frame,
                text='Hidden Message:',
                font=('Arial', 12, 'bold'),
                bg='#f0f0f0',
                fg='#2c3e50'
            )
            message_label.pack(pady=(20, 5))
            
            # Text area with scrollbar
            text_frame = tk.Frame(decode_frame, bg='#f0f0f0')
            text_frame.pack(pady=10)
            
            text_area = tk.Text(
                text_frame,
                width=50,
                height=8,
                font=('Arial', 10),
                wrap=tk.WORD,
                relief='solid',
                borderwidth=1,
                state='normal'
            )
            scrollbar = tk.Scrollbar(text_frame, orient='vertical', command=text_area.yview)
            text_area.configure(yscrollcommand=scrollbar.set)
            
            text_area.insert('1.0', hidden_message)
            text_area.configure(state='disabled')
            
            text_area.pack(side='left', fill='both', expand=True)
            scrollbar.pack(side='right', fill='y')
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to decode message: {str(e)}")
            self.show_decode_menu()
            return
        
        # Button frame
        button_frame = tk.Frame(decode_frame, bg='#f0f0f0')
        button_frame.pack(pady=20)
        
        # Copy to clipboard button
        copy_btn = tk.Button(
            button_frame,
            text='📋 Copy Message',
            command=lambda: self.copy_to_clipboard(hidden_message),
            font=('Arial', 10),
            bg='#3498db',
            fg='white',
            padx=15,
            pady=8,
            relief='flat',
            cursor='hand2'
        )
        copy_btn.pack(side='left', padx=5)
        
        # Back button
        back_btn = tk.Button(
            button_frame,
            text='⬅️ Back',
            command=self.show_decode_menu,
            font=('Arial', 10),
            bg='#95a5a6',
            fg='white',
            padx=15,
            pady=8,
            relief='flat',
            cursor='hand2'
        )
        back_btn.pack(side='left', padx=5)

    def copy_to_clipboard(self, text):
        """Copy text to clipboard."""
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("Success", "Message copied to clipboard!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy to clipboard: {str(e)}")

    def encode_message(self, text_widget, image):
        """Encode a message into the image."""
        try:
            message = text_widget.get("1.0", "end-1c").strip()
            
            if not message:
                messagebox.showwarning("Warning", "Please enter a message to encode!")
                return
            
            # Check if message is too long for the image
            max_chars = (image.size[0] * image.size[1] * 3) // 8
            if len(message) > max_chars - 1:  # -1 for delimiter
                messagebox.showerror(
                    "Error", 
                    f"Message too long! Maximum {max_chars-1} characters allowed for this image."
                )
                return
            
            # Create a copy of the image for encoding
            encoded_image = image.copy()
            
            # Encode the message
            self._encode_message_in_image(encoded_image, message)
            
            # Save the encoded image
            save_path = filedialog.asksaveasfilename(
                title="Save Encoded Image",
                defaultextension=".png",
                filetypes=[
                    ('PNG files', '*.png'),
                    ('JPEG files', '*.jpg'),
                    ('All files', '*.*')
                ]
            )
            
            if save_path:
                encoded_image.save(save_path)
                messagebox.showinfo(
                    "Success", 
                    f"Message successfully encoded and saved to:\n{save_path}"
                )
                self.show_main_menu()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to encode message: {str(e)}")

    def decode_message(self, image):
        """Decode a message from the image."""
        try:
            return self._decode_message_from_image(image)
        except Exception as e:
            raise Exception(f"No hidden message found or corrupted data: {str(e)}")

    def _encode_message_in_image(self, image, message):
        """Internal method to encode message using LSB steganography."""
        # Convert message to binary
        binary_message = ''.join(format(ord(char), '08b') for char in message)
        binary_message += '1111111111111110'  # Delimiter to mark end of message
        
        # Get image data
        pixels = list(image.getdata())
        
        # Encode message in LSB of pixels
        data_index = 0
        for i in range(len(pixels)):
            if data_index >= len(binary_message):
                break
                
            pixel = list(pixels[i])
            
            # Modify RGB values
            for j in range(3):  # RGB channels
                if data_index < len(binary_message):
                    # Set LSB to message bit
                    pixel[j] = pixel[j] & ~1 | int(binary_message[data_index])
                    data_index += 1
            
            pixels[i] = tuple(pixel)
        
        # Update image with modified pixels
        image.putdata(pixels)

    def _decode_message_from_image(self, image):
        """Internal method to decode message using LSB steganography."""
        # Get image data
        pixels = list(image.getdata())
        
        # Extract binary message from LSB
        binary_message = ""
        
        for pixel in pixels:
            for channel in pixel[:3]:  # RGB channels
                binary_message += str(channel & 1)
        
        # Find delimiter and extract message
        delimiter = '1111111111111110'
        delimiter_index = binary_message.find(delimiter)
        
        if delimiter_index == -1:
            raise Exception("No hidden message found")
        
        # Extract message binary
        message_binary = binary_message[:delimiter_index]
        
        # Convert binary to text
        if len(message_binary) % 8 != 0:
            raise Exception("Corrupted message data")
        
        message = ""
        for i in range(0, len(message_binary), 8):
            byte = message_binary[i:i+8]
            message += chr(int(byte, 2))
        
        return message

    def run(self):
        """Start the application."""
        try:
            root = self.create_main_window()
            root.mainloop()
        except Exception as e:
            messagebox.showerror("Error", f"Application error: {str(e)}")
            sys.exit(1)


def main():
    """Main function to run the application."""
    try:
        app = ImageSteganography()
        app.run()
    except Exception as e:
        print(f"Failed to start application: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
